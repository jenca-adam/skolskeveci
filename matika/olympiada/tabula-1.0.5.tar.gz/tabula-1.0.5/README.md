tabula
======

Ascii table

Dependencies
------------

    pip install numpy
